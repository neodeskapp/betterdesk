NeoDesk Console — Full Disaster-Recovery Backup
==================================================

Created:          2026-11-18T14:58:47.048Z
Console version:  3.5.224
Database engine:  postgres
Components:        console/data.json, goserver/data.json, console/.env, console/.session_secret, console/uploads/bg/nested.jpg, console/uploads/logo-0011.png, console/uploads/zz-ä.txt, goserver/id_ed25519, goserver/id_ed25519.pub, goserver/.api_key, goserver/mesh_agent_server.pem

WARNING: This archive contains SECRETS (Ed25519 server keys, .env with
SESSION_SECRET / API key / database credentials, user password hashes and
2FA secrets). Store it securely and never share it.

How to restore on a fresh machine
---------------------------------
1. Install NeoDesk using the ALL-IN-ONE installer (neodesk.sh / .ps1).
2. Stop the console and Go server services.
3. Open the web console Settings page and use "Restore from backup",
   OR extract this archive manually with: tar -xzf <backup>.tar.gz
   and copy each component back to its location:
     console/.env            -> web-nodejs/.env
     console/.session_secret -> <dataDir>/.session_secret
     console/auth.db         -> <dataDir>/auth.db   (SQLite backend only)
     console/uploads/*       -> <dataDir>/uploads/
     goserver/id_ed25519     -> <keysPath>/id_ed25519
     goserver/id_ed25519.pub -> <keysPath>/id_ed25519.pub
     goserver/.api_key       -> <keysPath>/.api_key
     goserver/mesh_agent_server.pem -> <keysPath>/mesh_agent_server.pem
     goserver/db_v2.sqlite3  -> Go server DB path (SQLite backend only)
4. For PostgreSQL backends, the logical dump in console/data.json is
   re-imported through the console Restore action.
5. Restart both services. Clients keep trusting the server because the
   Ed25519 identity key was preserved.
